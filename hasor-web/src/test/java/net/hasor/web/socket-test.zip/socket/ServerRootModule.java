package net.hasor.web.socket;
import net.hasor.web.WebApiBinder;
import net.hasor.web.WebModule;

import javax.servlet.ServletContext;
import javax.websocket.server.ServerContainer;
import javax.websocket.server.ServerEndpointConfig;
public class ServerRootModule implements WebModule {
    @Override
    public void loadModule(WebApiBinder apiBinder) throws Throwable {
        ServerContainer wscontainer = WebSocketServerContainerInitializer.configureContext(webAppContext);


                ServletContext servletContext = apiBinder.getServletContext();
        ServerContainer serverContainer = (ServerContainer) servletContext.getAttribute("javax.websocket.server.ServerContainer");
        System.out.println(serverContainer);
        //
        //
        serverContainer.addEndpoint(ServerEndpointConfig.Builder        //
                .create(SocketEndpoint.class, "/chat")              //
                .configurator(new ServerEndpointConfig.Configurator())  //
                .build()//
        );
    }
}
