package net.hasor.web.socket;
import net.hasor.web.startup.RuntimeFilter;
import net.hasor.web.startup.RuntimeListener;
import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ListenerHolder;
import org.eclipse.jetty.servlet.ServletContextHandler;

import javax.servlet.DispatcherType;
import java.util.EnumSet;
public class ServerMainTest {
    public static void main(String[] args) throws Exception {
        // . 启动多个端口
        Server server = new Server();
        ServerConnector connectorGateway = new ServerConnector(server);
        connectorGateway.setPort(8080);
        ServerConnector connectorApi = new ServerConnector(server);
        connectorApi.setPort(8082);
        server.setConnectors(new Connector[]{connectorGateway,connectorApi});
        //
        // .ServletContext
        ListenerHolder listenerHolder = new ListenerHolder();
        listenerHolder.setListener(new RuntimeListener ());
        ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
        context.getServletHandler().addListener(listenerHolder);
        context.setContextPath("/");
        context.setResourceBase(System.getProperty("java.io.tmpdir"));
        context.addFilter(RuntimeFilter.class, "/*", EnumSet.of(DispatcherType.REQUEST));
        server.setHandler(context);
        //
        //
        // 启动入口
        context.setInitParameter("hasor-root-module", "net.hasor.web.socket.ServerRootModule");
        // 配置文件名
        context.setInitParameter("hasor-hconfig-name", "hconfig.xml");
        // 环境变量
        context.setInitParameter("hasor-env-properties", "");
        //
        server.start();
        server.dumpStdErr();
        server.join();

    }
}
