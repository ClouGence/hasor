package net.hasor.web.socket;
import java.net.URI;
import java.net.URISyntaxException;
public class ClientMyApp {

    public static void main(String[] args) {
        try {
            // open websocket
            final ClientMyEndpoint clientEndPoint = new ClientMyEndpoint(new URI("wss://127.0.0.1:8080/chat"));

            // add listener
            clientEndPoint.addMessageHandler(new ClientMyEndpoint.MessageHandler() {
                public void handleMessage(String message) {
                    System.out.println(message);
                }
            });

            // send message to websocket
            clientEndPoint.sendMessage("{'event':'addChannel','channel':'ok_btccny_ticker'}");

            // wait 5 seconds for messages from websocket
            Thread.sleep(5000);

        } catch (InterruptedException ex) {
            System.err.println("InterruptedException exception: " + ex.getMessage());
        } catch (URISyntaxException ex) {
            System.err.println("URISyntaxException exception: " + ex.getMessage());
        }
    }
}