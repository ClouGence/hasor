/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package a.beanContextTest;
import java.io.File;
import java.net.URI;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.more.DoesSupportException;
import org.more.beans.BeanFactory;
import org.more.beans.BeanResource;
import org.more.beans.core.injection.ExportInjectionProperty;
import org.more.beans.core.injection.InjectionFactory;
import org.more.beans.info.BeanDefinition;
import org.more.beans.info.BeanProperty;
import org.more.beans.info.IocTypeEnum;
import org.springframework.context.support.FileSystemXmlApplicationContext;
public class Main {
    public static BeanDefinition def(IocTypeEnum iocType, String desc) {
        BeanDefinition bd = new BeanDefinition();
        bd.setIocType(iocType);
        bd.setName("bean");
        bd.setType("a.beanContextTest.Bean");
        bd.setFactIocRefBean("factIocRefBean");
        bd.setDescription(desc);
        bd.setPropertys(new BeanProperty[8]);
        //========
        BeanProperty bp = new BeanProperty();
        bp.setName("a");
        bp.setPropType("byte");
        bp.setValue("12");
        bd.getPropertys()[0] = bp;
        bp = new BeanProperty();
        bp.setName("b");
        bp.setPropType("short");
        bp.setValue("12");
        bd.getPropertys()[1] = bp;
        bp = new BeanProperty();
        bp.setName("c");
        bp.setPropType("int");
        bp.setValue("12");
        bd.getPropertys()[2] = bp;
        bp = new BeanProperty();
        bp.setName("d");
        bp.setPropType("long");
        bp.setValue("12");
        bd.getPropertys()[3] = bp;
        bp = new BeanProperty();
        bp.setName("e");
        bp.setPropType("float");
        bp.setValue("12.5");
        bd.getPropertys()[4] = bp;
        bp = new BeanProperty();
        bp.setName("f");
        bp.setPropType("double");
        bp.setValue("12.6");
        bd.getPropertys()[5] = bp;
        bp = new BeanProperty();
        bp.setName("g");
        bp.setPropType("boolean");
        bp.setValue("true");
        bd.getPropertys()[6] = bp;
        bp = new BeanProperty();
        bp.setName("h");
        bp.setPropType("java.lang.String");
        bp.setValue("�����ַ���");
        bd.getPropertys()[7] = bp;
        //        bp = new BeanProperty();
        //        bp.setName("i");
        //        bp.setPropType("java.util.Date");
        //        bp.setValue("�����ַ���");
        //        bd.getPropertys()[8] = bp;
        //        bp = new BeanProperty();
        //        bp.setName("j");
        //        bp.setPropType("Array");
        //        bp.setValue("�����ַ���");
        //        bd.getPropertys()[9] = bp;
        //        bp = new BeanProperty();
        //        bp.setName("k");
        //        bp.setPropType("List");
        //        bp.setValue("�����ַ���");
        //        bd.getPropertys()[10] = bp;
        //        bp = new BeanProperty();
        //        bp.setName("l");
        //        bp.setPropType("Map");
        //        bp.setValue("�����ַ���");
        //        bd.getPropertys()[11] = bp;
        //        bp = new BeanProperty();
        //        bp.setName("m");
        //        bp.setPropType("Set");
        //        bp.setValue("�����ַ���");
        //        bd.getPropertys()[12] = bp;
        //        bp = new BeanProperty();
        //        bp.setName("n");
        //        bp.setPropType("java.lang.StringBuffer");
        //        bp.setRefBean("refBean");
        //        bd.getPropertys()[13] = bp;
        return bd;
    }
    /**
     * @param args
     * @throws Throwable 
     */
    public static void main(String[] args) throws Throwable {
        BeanDefinition[] definition = new BeanDefinition[] { def(IocTypeEnum.Export, "Export"), def(IocTypeEnum.Fact, "Fact"), def(IocTypeEnum.Ioc, "Ioc") };
        BeanFactory context = new TestBeanFactory(definition);
        Object[] param = null;
        InjectionFactory injection = new InjectionFactory();
        //
        //
        for (BeanDefinition beanDef : definition) {
            long start = new Date().getTime();
            for (int i = 0; i < 1000000; i++)
                injection.ioc(new Bean(), param, beanDef, context);
            long end = new Date().getTime();
            System.out.println("time:" + (end - start) + "\t" + beanDef.getDescription());
        }
        //
        //
        long start2 = new Date().getTime();
        B bb = new B();
        for (int i = 0; i < 1000000; i++)
            bb.ioc(new Bean());
        long end2 = new Date().getTime();
        System.out.println("time:" + (end2 - start2) + "\tGet/Set");
        //
        //
        FileSystemXmlApplicationContext spring = new FileSystemXmlApplicationContext();
        spring.setConfigLocation("applicationContext.xml");
        spring.refresh();
        long start4 = new Date().getTime();
        for (int i = 0; i < 1000000; i++)
            spring.getBean("test");
        long end4 = new Date().getTime();
        System.out.println("time:" + (end4 - start4) + "\tSpringIoc");
        //
        //
    }
}
//time:3000     Fact
//time:5719     Ioc
//time:265      Export
//time:157      Get/Set
//
class B {
    public void ioc(Bean b) throws Throwable {
        b.setA((byte) 12);
        b.setB((short) 12);
        b.setC(12);
        b.setD(12L);
        b.setE(12.5F);
        b.setF(12.6D);
        b.setG(true);
        b.setH("�����ַ���");
    }
    public void aa(Bean b) {}
}
//===========================================================
/***/
class TestExportInjectionProperty implements ExportInjectionProperty {
    @Override
    public void injectionProperty(Object object, Object[] getBeanParam, BeanDefinition definition, BeanFactory context) {
        Bean b = (Bean) object;
        b.setA((byte) 12);
        b.setB((short) 12);
        b.setC(12);
        b.setD(12L);
        b.setE(12.5F);
        b.setF(12.6D);
        b.setG(true);
        b.setH("�����ַ���");
    }
}
/***/
class TestBeanFactory implements BeanFactory {
    private HashMap<String, BeanDefinition> beans = new HashMap<String, BeanDefinition>();
    public TestBeanFactory(BeanDefinition[] definition) {
        for (BeanDefinition def : definition)
            this.beans.put(def.getName(), def);
        BeanDefinition bd = new BeanDefinition();
        bd.setName("factIocRefBean");
        bd.setIocType(IocTypeEnum.Ioc);
        bd.setType("a.beanContextTest.TestExportInjectionProperty");
        bd.setDescription("");
        bd.setSingleton(true);
        bd.setAttribute("obj", new TestExportInjectionProperty());
        this.beans.put(bd.getName(), bd);
    }
    @Override
    public boolean containsBean(String name) {
        return true;
    }
    @Override
    public Object getBean(String name, Object... objects) {
        try {
            BeanDefinition bd = this.beans.get(name);
            Object obj = bd.get("obj");
            if (obj != null)
                return obj;
            else
                return Class.forName(this.beans.get(name).getType()).newInstance();
        } catch (Exception e) {}
        return null;
    }
    @Override
    public BeanResource getBeanResource() {
        return new BeanResource() {
            @Override
            public boolean isSingleton(String name) {
                return false;
            }
            @Override
            public boolean isPrototype(String name) {
                return false;
            }
            @Override
            public boolean isFactory(String name) {
                return false;
            }
            @Override
            public boolean isCacheBeanMetadata() {
                return false;
            }
            @Override
            public List<String> getStrartInitBeanDefinitionNames() {
                return null;
            }
            @Override
            public URL getSourceURL() {
                return null;
            }
            @Override
            public URI getSourceURI() {
                return null;
            }
            @Override
            public String getSourceName() {
                return null;
            }
            @Override
            public File getSourceFile() {
                return null;
            }
            @Override
            public String getResourceDescription() {
                return null;
            }
            @Override
            public List<String> getBeanDefinitionNames() {
                return null;
            }
            @Override
            public BeanDefinition getBeanDefinition(String name) {
                return null;
            }
            @Override
            public ClassLoader getBeanClassLoader() {
                return Thread.currentThread().getContextClassLoader();
            }
            @Override
            public Object getAttribute(String key) throws DoesSupportException {
                return null;
            }
            @Override
            public boolean containsBeanDefinition(String name) {
                return false;
            }
            @Override
            public void clearCache() throws DoesSupportException {}
        };
    }
    @Override
    public Class<?> getBeanType(String name) {
        return null;
    }
    @Override
    public Class<?> getOriginalBeanType(String name) {
        return null;
    }
    @Override
    public boolean isFactory(String name) {
        return this.beans.get(name).isFactory();
    }
    @Override
    public boolean isPrototype(String name) {
        return this.beans.get(name).isPrototype();
    }
    @Override
    public boolean isSingleton(String name) {
        return this.beans.get(name).isSingleton();
    }
    @Override
    public boolean isTypeMatch(String name, Class<?> targetType) {
        return false;
    }
}
